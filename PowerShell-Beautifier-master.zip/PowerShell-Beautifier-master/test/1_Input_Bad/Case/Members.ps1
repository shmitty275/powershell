(Get-Item c:\temp).PSISCONTAINER

(5 - 3).tostring() + "5"

[guid]::NEWGUID().TOSTRING().TOLOWER()

[string]::joIN('+',(1..5))
