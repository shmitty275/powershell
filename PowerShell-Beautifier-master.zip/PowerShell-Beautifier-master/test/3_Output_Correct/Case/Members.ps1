(Get-Item c:\temp).PSIsContainer

(5 - 3).ToString() + "5"

[guid]::NewGuid().ToString().ToLower()

[string]::Join('+',(1..5))
