# line endings in this file are just ASCII 10 LF not 13 10 CR LF
$i = 1
$j = 2

