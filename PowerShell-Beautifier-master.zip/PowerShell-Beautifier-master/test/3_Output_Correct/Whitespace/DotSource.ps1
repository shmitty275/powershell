. File.ps1
. File.ps1
. ./File1.ps1
. ../File2.ps1

& ./binary.exe

(0..9)
