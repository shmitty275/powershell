# SHB information related to HP hardware, firmware, and drivers

* [Survey answers](./Survey.md) - Community provided answers to the [survey questions](./../README.md#hardware-and-firmware-survey).
* [Updates](./Updates.md) - System firmware/BIOS and device driver updates published to fix Windows 10 compatibility issues.